#ler o "N":
n = int(input())

# calcular a quantidade de peças:

qpecas = ((n+1)*(n+2))/2

print (int(qpecas))


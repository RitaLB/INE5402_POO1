#lendo n:
n = int(input())

#construindo dicionario:

for i in range(n):
    frase = input()

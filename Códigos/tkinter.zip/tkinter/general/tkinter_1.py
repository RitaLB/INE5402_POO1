#importar conteúdo do módulo tkinter do python:
From Tkinter import *

#listagem 1 interface:

# na classe application criaremos os controles que serão exibidos na tela
class Application:
    def __init__(self, master=None):
        pass
root = Tk()
Application(root)
root.mainloop()
